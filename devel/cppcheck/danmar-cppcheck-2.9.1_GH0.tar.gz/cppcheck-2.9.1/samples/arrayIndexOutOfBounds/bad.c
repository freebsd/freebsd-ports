int a[2];

int main()
{
    a[0] = 0;
    a[1] = 0;
    a[2] = 0;
    return a[0];
}
